plugins {
    id("com.android.application")
    kotlin("android")
}
android {
    namespace = "com.onesystem.clothingerp"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.onesystem.clothingerp"
        minSdk = 24
        targetSdk = 35
        versionCode = 10
        versionName = "1.0.0"
    }
}
