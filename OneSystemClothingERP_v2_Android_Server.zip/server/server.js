const express=require("express");
const http=require("http");
const {Server}=require("socket.io");
const Database=require("better-sqlite3");
const path=require("path");
const app=express(), server=http.createServer(app), io=new Server(server);
const db=new Database("one_system_clothing.db");
db.pragma("journal_mode=WAL");
app.use(express.json()); app.use(express.static(path.join(__dirname,"../public")));

db.exec(`
CREATE TABLE IF NOT EXISTS products(id INTEGER PRIMARY KEY AUTOINCREMENT,code TEXT UNIQUE,name TEXT NOT NULL,category TEXT,color TEXT,size TEXT,sale_price REAL DEFAULT 0,stock REAL DEFAULT 0,min_stock REAL DEFAULT 0);
CREATE TABLE IF NOT EXISTS materials(id INTEGER PRIMARY KEY AUTOINCREMENT,code TEXT UNIQUE,name TEXT NOT NULL,unit TEXT DEFAULT 'متر',stock REAL DEFAULT 0,min_stock REAL DEFAULT 0,cost REAL DEFAULT 0);
CREATE TABLE IF NOT EXISTS bom(id INTEGER PRIMARY KEY AUTOINCREMENT,product_id INTEGER NOT NULL,material_id INTEGER NOT NULL,qty_per_unit REAL NOT NULL,waste_pct REAL DEFAULT 0);
CREATE TABLE IF NOT EXISTS suppliers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,phone TEXT,notes TEXT);
CREATE TABLE IF NOT EXISTS customers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,phone TEXT,notes TEXT);
CREATE TABLE IF NOT EXISTS purchases(id INTEGER PRIMARY KEY AUTOINCREMENT,supplier_id INTEGER,material_id INTEGER,qty REAL,unit_cost REAL,total REAL,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS sales(id INTEGER PRIMARY KEY AUTOINCREMENT,customer_id INTEGER,product_id INTEGER,qty REAL,unit_price REAL,total REAL,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS cutting_orders(id INTEGER PRIMARY KEY AUTOINCREMENT,order_no TEXT UNIQUE,product_id INTEGER,qty REAL,status TEXT DEFAULT 'مفتوح',created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS sewing_lines(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT UNIQUE);
CREATE TABLE IF NOT EXISTS production(id INTEGER PRIMARY KEY AUTOINCREMENT,cutting_id INTEGER,sewing_line_id INTEGER,product_id INTEGER,qty REAL,stage TEXT DEFAULT 'خياطة',status TEXT DEFAULT 'مفتوح',created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS stock_moves(id INTEGER PRIMARY KEY AUTOINCREMENT,item_type TEXT,item_id INTEGER,move_type TEXT,qty REAL,ref TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
`);

const n=x=>Number.isFinite(Number(x))?Number(x):0;
const rows=t=>db.prepare(`SELECT * FROM ${t} ORDER BY id DESC`).all();
const emit=()=>io.emit("data_changed");

app.get("/api/dashboard",(q,s)=>{
 const p=db.prepare("SELECT COUNT(*) c FROM products").get().c,m=db.prepare("SELECT COUNT(*) c FROM materials").get().c;
 const stock=db.prepare("SELECT COALESCE(SUM(stock*sale_price),0) v FROM products").get().v;
 const todaySales=db.prepare("SELECT COALESCE(SUM(total),0) v FROM sales WHERE date(created_at)=date('now')").get().v;
 const todayPurch=db.prepare("SELECT COALESCE(SUM(total),0) v FROM purchases WHERE date(created_at)=date('now')").get().v;
 const cutting=db.prepare("SELECT COUNT(*) c FROM cutting_orders WHERE status!='مغلق'").get().c;
 const prod=db.prepare("SELECT COUNT(*) c FROM production WHERE status!='مغلق'").get().c;
 s.json({products:p,materials:m,stock_value:stock,todaySales,todayPurch,cutting,prod});
});

app.get("/api/products",(q,s)=>s.json(rows("products")));
app.post("/api/products",(q,s)=>{let x=q.body;try{let r=db.prepare("INSERT INTO products(code,name,category,color,size,sale_price,min_stock) VALUES(?,?,?,?,?,?,?)").run(x.code,x.name,x.category||"",x.color||"",x.size||"",n(x.sale_price),n(x.min_stock));emit();s.json({ok:true,id:r.lastInsertRowid})}catch(e){s.status(400).json({error:e.message})}});
app.delete("/api/products/:id",(q,s)=>{db.prepare("DELETE FROM products WHERE id=?").run(q.params.id);emit();s.json({ok:true})});

app.get("/api/materials",(q,s)=>s.json(rows("materials")));
app.post("/api/materials",(q,s)=>{let x=q.body;try{let r=db.prepare("INSERT INTO materials(code,name,unit,stock,min_stock,cost) VALUES(?,?,?,?,?,?)").run(x.code,x.name,x.unit||"متر",n(x.stock),n(x.min_stock),n(x.cost));emit();s.json({ok:true,id:r.lastInsertRowid})}catch(e){s.status(400).json({error:e.message})}});

app.get("/api/bom/:productId",(q,s)=>s.json(db.prepare(`SELECT b.*,m.code material_code,m.name material_name,m.unit,m.cost FROM bom b JOIN materials m ON m.id=b.material_id WHERE b.product_id=? ORDER BY b.id`).all(q.params.productId)));
app.post("/api/bom",(q,s)=>{let x=q.body;db.prepare("INSERT INTO bom(product_id,material_id,qty_per_unit,waste_pct) VALUES(?,?,?,?)").run(x.product_id,x.material_id,n(x.qty_per_unit),n(x.waste_pct));emit();s.json({ok:true})});
app.delete("/api/bom/:id",(q,s)=>{db.prepare("DELETE FROM bom WHERE id=?").run(q.params.id);emit();s.json({ok:true})});
app.get("/api/cost/:productId",(q,s)=>{
 const r=db.prepare(`SELECT COALESCE(SUM((b.qty_per_unit*(1+b.waste_pct/100))*m.cost),0) material_cost FROM bom b JOIN materials m ON m.id=b.material_id WHERE b.product_id=?`).get(q.params.productId);
 s.json({material_cost:r.material_cost||0});
});

app.get("/api/cutting",(q,s)=>s.json(db.prepare(`SELECT c.*,p.name product_name,p.code product_code FROM cutting_orders c JOIN products p ON p.id=c.product_id ORDER BY c.id DESC`).all()));
app.post("/api/cutting",(q,s)=>{
 let x=q.body, qty=n(x.qty);
 const tx=db.transaction(()=>{
   const r=db.prepare("INSERT INTO cutting_orders(order_no,product_id,qty) VALUES(?,?,?)").run(x.order_no||"CUT-"+Date.now(),x.product_id,qty);
   const bom=db.prepare("SELECT * FROM bom WHERE product_id=?").all(x.product_id);
   for(const b of bom){
     const need=qty*b.qty_per_unit*(1+b.waste_pct/100);
     const mat=db.prepare("SELECT stock FROM materials WHERE id=?").get(b.material_id);
     if(!mat || mat.stock<need) throw new Error("رصيد خامة غير كافٍ في أمر القص");
     db.prepare("UPDATE materials SET stock=stock-? WHERE id=?").run(need,b.material_id);
     db.prepare("INSERT INTO stock_moves(item_type,item_id,move_type,qty,ref) VALUES('material',?,'صرف قص',?,?)").run(b.material_id,need,"أمر "+r.lastInsertRowid);
   }
   return r.lastInsertRowid;
 });
 try{let id=tx();emit();s.json({ok:true,id})}catch(e){s.status(400).json({error:e.message})}
});

app.get("/api/lines",(q,s)=>s.json(rows("sewing_lines")));
app.post("/api/lines",(q,s)=>{try{let r=db.prepare("INSERT INTO sewing_lines(name) VALUES(?)").run(q.body.name);emit();s.json({ok:true,id:r.lastInsertRowid})}catch(e){s.status(400).json({error:e.message})}});

app.get("/api/production",(q,s)=>s.json(db.prepare(`SELECT pr.*,p.name product_name,l.name line_name,c.order_no cut_order FROM production pr JOIN products p ON p.id=pr.product_id LEFT JOIN sewing_lines l ON l.id=pr.sewing_line_id LEFT JOIN cutting_orders c ON c.id=pr.cutting_id ORDER BY pr.id DESC`).all()));
app.post("/api/production",(q,s)=>{let x=q.body;db.prepare("INSERT INTO production(cutting_id,sewing_line_id,product_id,qty,stage) VALUES(?,?,?,?,?)").run(x.cutting_id||null,x.sewing_line_id||null,x.product_id,n(x.qty),x.stage||"خياطة");emit();s.json({ok:true})});
app.patch("/api/production/:id",(q,s)=>{let x=q.body;db.prepare("UPDATE production SET stage=COALESCE(?,stage),status=COALESCE(?,status) WHERE id=?").run(x.stage||null,x.status||null,q.params.id);emit();s.json({ok:true})});
app.post("/api/production/:id/finish",(q,s)=>{
 let o=db.prepare("SELECT * FROM production WHERE id=?").get(q.params.id); if(!o)return s.status(404).json({error:"الأمر غير موجود"});
 const tx=db.transaction(()=>{
   db.prepare("UPDATE production SET status='مغلق',stage='تشطيب' WHERE id=?").run(o.id);
   db.prepare("UPDATE products SET stock=stock+? WHERE id=?").run(o.qty,o.product_id);
   if(o.cutting_id)db.prepare("UPDATE cutting_orders SET status='مغلق' WHERE id=?").run(o.cutting_id);
   db.prepare("INSERT INTO stock_moves(item_type,item_id,move_type,qty,ref) VALUES('product',?,'إنتاج تام',?,?)").run(o.product_id,o.qty,"تشغيل "+o.id);
 });
 tx();emit();s.json({ok:true});
});

app.get("/api/purchases",(q,s)=>s.json(db.prepare(`SELECT p.*,m.name material_name,sp.name supplier_name FROM purchases p LEFT JOIN materials m ON m.id=p.material_id LEFT JOIN suppliers sp ON sp.id=p.supplier_id ORDER BY p.id DESC`).all()));
app.post("/api/purchases",(q,s)=>{let x=q.body,qty=n(x.qty),cost=n(x.unit_cost);const tx=db.transaction(()=>{db.prepare("INSERT INTO purchases(supplier_id,material_id,qty,unit_cost,total) VALUES(?,?,?,?,?)").run(x.supplier_id||null,x.material_id,qty,cost,qty*cost);db.prepare("UPDATE materials SET stock=stock+?,cost=? WHERE id=?").run(qty,cost,x.material_id)});tx();emit();s.json({ok:true})});
app.get("/api/sales",(q,s)=>s.json(db.prepare(`SELECT s.*,p.name product_name,c.name customer_name FROM sales s LEFT JOIN products p ON p.id=s.product_id LEFT JOIN customers c ON c.id=s.customer_id ORDER BY s.id DESC`).all()));
app.post("/api/sales",(q,s)=>{let x=q.body,qty=n(x.qty),price=n(x.unit_price);try{const tx=db.transaction(()=>{let p=db.prepare("SELECT stock FROM products WHERE id=?").get(x.product_id);if(!p||p.stock<qty)throw new Error("المخزون غير كاف");db.prepare("INSERT INTO sales(customer_id,product_id,qty,unit_price,total) VALUES(?,?,?,?,?)").run(x.customer_id||null,x.product_id,qty,price,qty*price);db.prepare("UPDATE products SET stock=stock-? WHERE id=?").run(qty,x.product_id)});tx();emit();s.json({ok:true})}catch(e){s.status(400).json({error:e.message})}});

app.get("/api/suppliers",(q,s)=>s.json(rows("suppliers")));
app.post("/api/suppliers",(q,s)=>{let x=q.body;db.prepare("INSERT INTO suppliers(name,phone,notes) VALUES(?,?,?)").run(x.name,x.phone||"",x.notes||"");emit();s.json({ok:true})});
app.get("/api/customers",(q,s)=>s.json(rows("customers")));
app.post("/api/customers",(q,s)=>{let x=q.body;db.prepare("INSERT INTO customers(name,phone,notes) VALUES(?,?,?)").run(x.name,x.phone||"",x.notes||"");emit();s.json({ok:true})});

app.get("/api/low-stock",(q,s)=>s.json({
 products:db.prepare("SELECT * FROM products WHERE stock<=min_stock").all(),
 materials:db.prepare("SELECT * FROM materials WHERE stock<=min_stock").all()
}));

app.get("/api/production-cost/:productId", (q,s)=>{
 const c=db.prepare(`SELECT COALESCE(SUM(b.qty_per_unit*(1+b.waste_pct/100)*m.cost),0) material FROM bom b JOIN materials m ON m.id=b.material_id WHERE b.product_id=?`).get(q.params.productId).material;
 s.json({material:c||0, estimated_total:c||0});
});
io.on("connection",sock=>sock.emit("connected",{ok:true}));
server.listen(process.env.PORT||3000,"0.0.0.0",()=>console.log("ERP v2 server on port 3000"));
